#!/system/bin/sh

# Pastikan folder ada di awal boot
TARGET="/data/vendor/mcRegistry"
if [ ! -d "$TARGET" ]; then
    mkdir -p "$TARGET"
    chown system:system "$TARGET"
    chmod 0755 "$TARGET"
fi

# Set Permissive gaya lama
if [ -x "$(command -v setenforce)" ]; then
    setenforce 0
else
    printf '0' > /sys/fs/selinux/enforce
fi

# Sembunyikan status permissive dari apps
chmod 640 /sys/fs/selinux/enforce 