#!/system/bin/sh

ui_print "************************************"
ui_print "    FIX LOCKSCREEN A10S (MOD)       "
ui_print "************************************"

# Cek Model Device
MODEL="$(getprop ro.product.model)"
ui_print "- Checking device: $MODEL"

case "$MODEL" in
    SM-A107F|SM-A107M)
        ui_print "- A10s detected. Proceeding..."
        ;;
    *)
        ui_print "- Not supported device. Skipping."
        abort "Aborting: Device mismatch."
        ;;
esac

# Buat folder mcRegistry
TARGET="/data/vendor/mcRegistry"
ui_print "- Setting up $TARGET"
mkdir -p "$TARGET"
set_perm "$TARGET" system system 0755

ui_print "- WARNING: SELinux will be set to Permissive."
ui_print "- Done. Reboot required." 