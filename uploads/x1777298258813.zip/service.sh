#!/system/bin/sh

# Tunggu sampai boot selesai
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

# Paksa Permissive lagi
if [ -x "$(command -v setenforce)" ]; then
    setenforce 0
else
    printf '0' > /sys/fs/selinux/enforce
fi

# Manipulasi properti agar sistem terlihat Enforcing di mata beberapa aplikasi
if [ -x "$(command -v resetprop)" ]; then
    resetprop -n ro.boot.selinux enforcing
    resetprop --delete ro.build.selinux
fi 