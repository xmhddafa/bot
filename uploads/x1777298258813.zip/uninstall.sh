#!/system/bin/sh
chmod 644 /sys/fs/selinux/enforce
if [ -x "$(command -v resetprop)" ]; then
    resetprop --delete ro.boot.selinux
fi 