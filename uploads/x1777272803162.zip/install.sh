#!/system/bin/sh

ui_print() { echo "$1"; }

MODEL="$(getprop ro.product.model)"
TARGET="/data/vendor/mcRegistry"

ui_print "[A10S-FIX] Checking device..."

case "$MODEL" in
    SM-A107F|SM-A107M)
        ui_print "[A10S-FIX] A10s detected ($MODEL)"
        ;;
    *)
        ui_print "[A10S-FIX] Not supported ($MODEL), skip"
        exit 0
        ;;
esac

mkdir -p "$TARGET"
chown system:system "$TARGET"
chmod 0755 "$TARGET"

ui_print "[A10S-FIX] Done"
