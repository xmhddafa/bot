#!/system/bin/sh

MODTAG="[A10S-FIX]"
LOG="/data/local/tmp/a10s_vendor_fix.log"
TARGET="/data/vendor/mcRegistry"

log() {
    echo "$MODTAG $1" >> "$LOG"
}

MODEL="$(getprop ro.product.model)"

case "$MODEL" in
    SM-A107F|SM-A107M)
        log "Device OK: $MODEL"
        ;;
    *)
        log "Skip: not A10s ($MODEL)"
        exit 0
        ;;
esac

if [ ! -d /data/vendor ]; then
    mkdir -p /data/vendor
    chown system:system /data/vendor
    chmod 0770 /data/vendor
    log "Created /data/vendor"
fi

if [ ! -d "$TARGET" ]; then
    mkdir -p "$TARGET"
    chown system:system "$TARGET"
    chmod 0755 "$TARGET"
    log "mcRegistry created"
else
    log "mcRegistry already exists"
fi

if command -v restorecon >/dev/null 2>&1; then
    restorecon "$TARGET" 2>/dev/null
    log "SELinux context restored"
else
    log "restorecon not available"
fi

log "Done"
