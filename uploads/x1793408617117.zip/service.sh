#!/system/bin/sh
# Sole start path for the HAL. No init.rc "class hal" service is used here -
# that approach caused a bootloop on this device. This runs via Magisk's
# late_start service class, well after zygote/system_server are already up,
# and forces a rebind the same way the proven-working v8 module did:
# stop the legacy HIDL vibrator service (if present) and kill system_server
# so it re-resolves to this AIDL service on respawn.

LD_LIBRARY_PATH=/system/lib64 /data/adb/modules/vibrator-aidl-hal/system/vendor/bin/vibrator-service.bin &
sleep 4
stop android.hardware.vibrator@1.0-service
kill $(pidof system_server)
